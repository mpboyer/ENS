# Instructions Générales

- Le programme se compile puis s'exécute avec `make`
- Il faut repérer, par des clics gauches, les paires de points à identifier pour l'homographie.
- Il n'est pas nécessaire de faire un clic dans une fenêtre puis un clic dans l'autre, mais les points seront identifiés selon l'ordre dans lequel ils ont été marqués dans la fenêtre en question.
- Il faut au moins avoir ajouté quatre points.
